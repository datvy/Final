import greenfoot.*;
import java.util.ArrayList;
import java.util.Random;

public class Game extends World {
    // Instance Variables for Game
    private Note note0;
    private Note note1;
    private Note note2;
    private Note note3;
    private Note note4;
    private Note note5;
    private Note note6;
    private Note note7;
    private Note note8;
    private Note note9;
    private Note[] noteArray;
    private int addTimer;
    private int cheatTimer;
    private int score;

    // Constructer for Game
    public Game() {

        // Makes Game and Defines all Note objects
        super(600, 400, 1);
        note0 = new Note(0, false, 3, false);
        note1 = new Note(0, false, 3, false);
        note2 = new Note(0, false, 3, false);
        note3 = new Note(0, false, 3, false);
        note4 = new Note(0, false, 3, false);
        note5 = new Note(0, false, 3, false);
        note6 = new Note(0, false, 3, false);
        note7 = new Note(0, false, 3, false);
        note8 = new Note(0, false, 3, false);
        note9 = new Note(0, false, 3, false);

        // Puts Notes in noteArray
        noteArray = new Note[10];
        noteArray[0] = note0;
        noteArray[1] = note1;
        noteArray[2] = note2;
        noteArray[3] = note3;
        noteArray[4] = note4;
        noteArray[5] = note5;
        noteArray[6] = note6;
        noteArray[7] = note7;
        noteArray[8] = note8;
        noteArray[9] = note9;

        // Defines timers
        addTimer = 0;
        cheatTimer = 0;
        score = 0;
    }

    // Act method that runs every frame
    public void act() {

        // Spawns notes and increments score, Uses timers
        if (addTimer % calcAddTime() == 0) {

            addObject(getNote(), 0, 0);
            addTimer = 0;

            updateScore();

        }

        // Checks for holding down keys
        checkCheat();

        // Shows score
        showText("Score: " + score, 40, 20);

        // Checks if note was missed
        checkMiss();

        // Increments main timer for adding notes
        addTimer++;

    }

    // Calculates the interval that at which notes are added
    public int calcAddTime() {

        if (50 - noteArray[0].getScrollSpeed() > 10) {

            return 50 - (noteArray[0].getScrollSpeed() * 2);

        } else return 10;

    }

    // Is called to increment Score
    public void updateScore() {

        score++;

    }

    // Is called to check if a note was missed, if so ends game
    public void checkMiss() {

        for (int i = 0; i < noteArray.length; i++) {

            if (noteArray[i].getInUse() && noteArray[i].getX() == 599) {

                endGame();

            }

        }

    }

    // Returns a note that is not in use from noteArray
    public Note getNote() {

        for (int i = 0; i < noteArray.length; i++) {

            if (!noteArray[i].getInUse()) {

                noteArray[i].setRow(randomRow());
                noteArray[i].setInUse(true);

                return noteArray[i];

            }

        }

        return noteArray[randomRow()];

    }

    // Is called to calc a random row
    public int randomRow() {

        Random rand = new Random();

        return rand.nextInt(100) / 25;

    }

    // is Called to check if player is holding keys
    public void checkCheat() {

        for (Note n: noteArray) {

            if (n.getInUse() && n.checkCheat()) {

                endGame();

            }

        }

        cheatTimer--;

    }

    // is called to end the game
    public void endGame() {

        showText("YOUR SCORE: " + score, 300, 200);

        Greenfoot.stop();

    }
}
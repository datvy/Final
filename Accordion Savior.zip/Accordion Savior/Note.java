import greenfoot.*;
public class Note extends Actor {
    // Initializes instance variables for Note
    private int row; //the row determines the key
    private boolean inUse;
    private static int scrollSpeed; //the speed the notes scroll at
    private final String[] noteKey = {
        "2",
        "q",
        "a",
        "z"
    };
    private final String[] colorKey = {
        "BlueNote.png",
        "GreenNote.png",
        "RedNote.png",
        "YellowNote.png"
    };
    private final int[] postitionKey = {
        62,
        154,
        246,
        337
    };
    private final String[] soundKey = {
        "C.mp3",
        "E.mp3",
        "G.mp3",
        "C2.mp3"
    };
    private int timer;
    private int cheatTimer;
    //constructor
    public Note(int row, boolean isHit, int scrollSpeed, boolean inUse) {
        this.row = row;
        this.scrollSpeed = scrollSpeed;
        this.inUse = inUse;
        timer = 0;
        cheatTimer = 0;
    }

    //getters and setters
    public int getRow() {
        return row;
    }
    public static int getScrollSpeed() {
        return scrollSpeed;
    }
    public boolean getInUse() {
        return inUse;
    }
    public void setRow(int thisRow) {
        row = thisRow;
    }
    public static void setScrollSpeed(int thisScrollSpeed) {
        scrollSpeed = thisScrollSpeed;
    }
    public void setInUse(boolean thisInUse) {
        inUse = thisInUse;
    }
    //end getters and setters 

    // is called to move the notes on screen
    public void move() {

        if (inUse) {
            setLocation(getX() + scrollSpeed, postitionKey[row]);
        }

    }

    // is called to increment the speed of the notes
    public void incrementSpeed() { //increment speed
        int inc = 1; //the change in the speed, subject to change
        scrollSpeed += inc;
    }

    // checks if the player is holding down keys
    public boolean checkCheat() {
        
        if (cheatTimer > 45) {

            return true;

        }

        if (this.getInUse() && Greenfoot.isKeyDown(noteKey[this.row])) {

            cheatTimer++;

        } else cheatTimer = 0;

        return false;

    }

    // checks if the note was hit on time
    public boolean hitNote() {

        if (this.getInUse() && Greenfoot.isKeyDown(noteKey[this.row]) && this.getX() > 450) {

            return true;

        } else return false;

    }

    // Runs every frame
    public void act() {

        // calls move method to update note pos
        move();

        // if note was hit then despawns note and resets them for use again
        if (hitNote()) {

            Greenfoot.playSound(soundKey[row]);
            
            this.getWorld().removeObject(this);

            this.setRow((int) Math.random() * 3);

            this.setInUse(false);

        }

        // sets the note color for its row
        setImage(colorKey[row]);

        // increments speed of notes every 1000 frames
        if (timer > 1000) {

            incrementSpeed();

            timer = 0;

        }

        // increments timer var
        timer++;

    }
}